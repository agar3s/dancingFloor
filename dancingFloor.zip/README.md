# I bet that your minions look good in the dance floor

## LudumDare41 entry by Agar3s


A rythm turn based card game where you need to rule the dancing floor!

